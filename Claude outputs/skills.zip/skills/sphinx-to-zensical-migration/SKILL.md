---
name: "sphinx-to-zensical-migration"
description: "Use when migrating one of the user's Sphinx, MyST or Jupyter Book tutorial sites to Zensical, including the audit, branch setup, config, colour theme, deploy workflow, go-live and the VS Code handoff file."
---

# Sphinx to Zensical migration

The process used to move *Python meets micro:bit* (damom73/microbit_python) from Sphinx to Zensical, refined on *Lego Spike Python Coding*, *A Turtle Introduction to Python*, *Deepest Dungeon - Python OOP* and *Space Rescue* (a Pygame/GameFrame game built across lessons, with new mechanic pages written from scratch). Use it for the user's other Sphinx/MyST tutorial sites. Pair it with the `tutorial-page-style` skill for writing pages and the `tutorial-code-files` skill for examples, exercises and solutions.

The user is a Queensland secondary Digital Technologies teacher. Write in Australian English, give technical instructions one step at a time (step, reason, expected result), and ask rather than assume. Use AskUserQuestion with clickable options, and allow several answers where that makes sense.

## Phase 1: Audit (no changes yet)

1. Ask for the live site URL and the local repo path. The user's repos are in `D:\GIT\<repo>` on the desktop (device `damopc`) and `C:\GitHub\<repo>` on the laptop (Surface, device `damo-surface`). Check which computer is linked with `get_device_info`, and confirm the path before requesting folder access. Read the live site and the repo's `conf.py`, `index.md`/`_toc.yml`, the numbered pages, `_static/`, `assets/` and any code folders.
    - The pages are the source of truth for code. Old code folders (such as `python_files/`) are often out of date; compare them with the pages and note any mismatch.
    - On sites that repeat the same file across a page or across pages, check each copy against the one before it. Look for fixes that were made once and then lost in later copies, and for "final code" sections pasted from an older version. When a difference might be deliberate (for example a planted bug for students to find), ask the user rather than guessing.
    - Run the old site's code, don't just read it. Rebuild the program at the end of every page and run it headless with scripted input (for Pygame: SDL dummy drivers and a stubbed `pygame.key.get_pressed`; see `tutorial-code-files`). On Space Rescue this found a crash on the second game (lives never reset), a page whose "completed files" left out a changed file, and music that started a second copy every round.
    - Check file names in code against the real files, including capitals. `"Background.png"` for ***background.png*** works on Windows but crashes on macOS and Linux, so it's easy to miss.
    - Check any API reference page against the library's source, not just its old docs. Space Rescue's GameFrame page had `set_direction` angles backwards (they're clockwise, so 90° is down), `delete_object` taking a string (it takes the object) and a method with a parameter it doesn't have.
    - A site the user has already migrated is the best template. Ask for folder access to it and reuse its `zensical.toml`, `extra.css`, `scripts/`, `VSCODE_CLAUDE_TASKS.md` and shared guide pages (for example the *Debugging with Thonny* guide, which several sites share with the same screenshots).
2. Ask about scope, with multi-select options:
    - audience (year level)
    - editor or tooling students use (for example Thonny or VS Code)
    - what to keep: videos, exercises, solutions, guides, grouping
    - content to add or drop
    - site type: component reference, sequential lessons, project/challenge guides, or mixed
    - how much the prose should change: house style ("we" voice, callouts, Code explanation boxes) or a light touch
    - items in the repo's own `todo.md` or similar notes: offer them as new pages
3. Write an audit and rework plan: page inventory, proposed nav, bugs and outdated facts found, pedagogical observations, and file moves. Save it to the Claude project as `claude/<repo>_rework_plan.md`. Get the plan approved before building.

## Phase 2: Branch

Keep the original site on `main`. Guide the user through GitHub Desktop one step at a time: **Current branch** → **New branch** → name it `zensical`, based on `main` → **Publish branch**. Confirm the branch shows in the local folder before writing anything.

The build can go ahead in the cloud workspace while the user sets up the branch. Nothing is written to their folder until the branch is confirmed.

To confirm the branch, list `.git/refs/heads` and stage `.git/HEAD`. A newly staged `.git/HEAD` can come back stale, so trust `refs/heads` and the `mtimeMs` values. If `refs/heads` has no `zensical`, GitHub Desktop is probably looking at a different copy of the repo (or the branch was made on another computer). Ask the user to check with **Repository** → **Show in Explorer**.

## Phase 3: Structure

```
zensical.toml
requirements.txt          # zensical==<pinned version>
docs/
  index.md
  <section>/<page>.md
  examples/<group>/<page>/<example>/main.py
  solutions/<group>/<page>/exN_name.py
  assets/                 # images, GIFs, logo, favicon
  stylesheets/extra.css
  downloads/<name>_tutorials.zip
scripts/
  make_zip.py
  check_explanations.py
```

### zensical.toml essentials

- `[project]`: `site_name`, `site_description`, `site_author`, `site_url` (keep the same GitHub Pages URL), `repo_url`, `repo_name`, `copyright` ("Content licensed under CC BY-NC-SA 4.0. Code licensed under GPLv3." unless the user says otherwise), `docs_dir = "docs"`, `extra_css = ["stylesheets/extra.css"]`, and an explicit `nav` list.
- `[project.theme]`: `language = "en"`, `logo`, `favicon`, and these features: `content.code.copy`, `content.code.select`, `navigation.footer`, `navigation.indexes`, `navigation.instant`, `navigation.path`, `navigation.sections`, `navigation.tabs`, `navigation.top`, `navigation.tracking`, `search.highlight`.
- Three `[[project.theme.palette]]` entries: system (`lucide/sun-moon`), light (`scheme = "default"`, `lucide/sun`) and dark (`scheme = "slate"`, `lucide/moon`). Light and dark both use `primary = "custom"` and `accent = "custom"`.
- `[project.markdown_extensions]`: `admonition`, `attr_list`, `md_in_html`, `tables`, `toc.permalink = true`, `pymdownx.details`, `pymdownx.highlight` (`anchor_linenums`, `line_spans = "__span"`, `pygments_lang_class`), `pymdownx.inlinehilite`, `pymdownx.keys`, `pymdownx.snippets.base_path = ["docs"]`, `pymdownx.snippets.check_paths = true`, `pymdownx.superfences`. Add `pymdownx.tabbed` only if the site needs tabs.

### Converting Sphinx/MyST syntax

| Sphinx / MyST | Zensical |
| --- | --- |
| `toctree` / `_toc.yml` | `nav` in zensical.toml |
| PRIMM ```` ```{note} Predict ```` / `Run` / `Investigate` boxes | one `!!! primm "PRIMM"` callout, then `??? note "Code explanation"` |
| ```` ```{topic} In this lesson you will learn ```` (learning intentions) | `!!! learn "In this lesson we will learn"` with a bullet list, moved directly under the title (above any video) |
| ```` ```{note} ````, `{hint}`, `{tip}`, other `{topic}` boxes and other asides | `!!! tip "Title"` with an indented body |
| ```` ```{warning} ```` | `!!! warning "Title"` |
| `{dropdown}` / `{admonition}` with `:class: dropdown` | `??? tip "Title"` (use `??? note` only for Code explanation) |
| `{code-block} python` | ```` ```python linenums="1" ```` |
| `{code-block} error` | ```` ``` { .text .error linenums="1" } ```` |
| `{literalinclude} file.py` | `--8<-- "examples/.../main.py"` inside a fenced block |
| `{image}` / `{figure}` | `![alt](../assets/file.png)` |
| raw YouTube iframe | keep the iframe but use `youtube-nocookie.com/embed/<id>` |
| `{ref}` / `{doc}` links | relative `.md` links |
| sphinx-design tabs | `=== "Tab"` (pymdownx.tabbed) |

### Colour theme (ask per site)

Ask for a five-colour palette. Map colours to roles by contrast: the darkest colour becomes the header, tabs, links, headings and active nav in light mode. Lighter colours are never used as text on white. Base `extra.css` on the micro:bit site's file:

- `:root` variables for the five colours
- `[data-md-color-scheme="default"]`: primary = dark colour; accent, links and headings = dark colour
- `[data-md-color-scheme="slate"]`: primary = dark colour; accent and headings = warm light colour; links = light blue
- headings coloured through `--heading-colour`, including `code` inside headings
- callouts and code blocks use the standard style below, not the site palette
- header and tabs in the dark colour with white text; the active or hovered tab uses the warm light colour
- active side-nav link bold
- white search button with a `#333333` icon and an `#eeeeee` Ctrl+K badge

Check the contrast of every text/background pair, and show the mapping to the user before applying it.

**The banner colour must be clearly different from the user's other tutorial sites**, so students can tell at a glance which site they're on. Current banners:

| Site | Banner (header, tabs, light-mode links and headings) |
| --- | --- |
| Python meets micro:bit | navy `#476088` |
| Lego Spike Python Coding | LEGO magenta `#923978` |
| A Turtle Introduction to Python | deep teal `#00696B` (changed from deep pink `#B0006E`, which was too close to the Lego magenta) |
| Deepest Dungeon - Python OOP | burnt orange `#A84300` (darkened from the old `#FF9100`); peach `#FFDFB4` for the active tab and dark-mode headings |
| Space Rescue | charcoal slate `#37474F` (9.6:1 with white); light grey `#CFD8DC` for the active tab and dark-mode headings |

- Also keep the banner away from the callout hues (amber, green, purple, light blue, hot pink).
- Before choosing, render a side-by-side image of the existing banners and three or four candidates, each labelled with its hex and its white-text contrast ratio (at least 4.5:1), and let the user pick with AskUserQuestion.
- When a site's banner changes, replace the old colour everywhere it's used (header, tabs, links, headings, active tab, dark-mode headings) unless the user asks to keep it as an accent, then update the colour scheme line in the handoff file's Context section and add the new site to the table above.

### Standard callout and code block style (same on every site)

Callouts and code blocks look the same on every tutorial site. Don't take their colours from the site's palette; the palette only sets the header, tabs, links and headings.

Every site uses exactly five callout types (see `tutorial-page-style`): `learn` (learning intentions), `primm`, `note` (Code explanation boxes only), `tip` (every other aside) and `warning`. Each gets the same look: a light tint of its colour, a thin border in a **darker shade** of that colour, a transparent title background, and the icon and dropdown arrow in the darker shade.

| Callout | Light mode | Dark mode | Icon |
| --- | --- | --- | --- |
| `learn` (learning intentions) | amber `#FFB300` | same | target (Lucide `target`, `--md-admonition-icon--learn`) |
| `primm` | green `#4D8A00` | `#7BC41A` | flask (Lucide `flask-conical`, `--md-admonition-icon--primm`) |
| `note` (Code explanation) | purple `#8400FF` | `#B77BFF` | code brackets (Lucide `code-xml`, `--md-admonition-icon--code`) |
| `tip` | light blue `#4FC3F7` | same | light bulb (Lucide `lightbulb`, `--md-admonition-icon--bulb`) |
| `warning` | hot pink `#FF00A1` | same | triangle alert (theme default) |
| any other type | `#448AFF` | same | theme default |

- Icons match what the callout holds: goals, an experiment, code, ideas and hazards.
- The four custom icons are Lucide SVGs defined in `extra.css` as data-URI variables and applied with `mask-image`, so they take the callout's darker shade. Get new Lucide paths from the `lucide-static` npm package (`npm pack lucide-static`) rather than typing them from memory, and swap `stroke="currentColor"` for `stroke="black"`.
- The darker border is `color-mix(in srgb, var(--callout) 70%, black)`, in both light and dark mode.
- The background is `color-mix(in srgb, var(--callout) 12%, transparent)`.
- The theme sets backgrounds and icon colours with type-specific selectors (`.md-typeset details.note`, `.md-typeset .note > summary:before`), so the style rules must name each type or the theme's blue and cyan defaults win. The `:is()` template below does this.
- Every code block (`div.highlight`) has a thin border in the theme's light grey, `var(--md-default-fg-color--lighter)`, with rounded corners. Inline code has no border.
- Error-message blocks (```` ``` { .text .error linenums="1" } ````) keep a red border and red text: `#D00000` in light mode, `#FF6B6B` in dark mode. Put the error rules after the code block rules so they win.

Template (copy as is into every site's `extra.css`):

```css
/* Callouts: every type uses the same style, a light tint of its colour
   with a darker border of the same colour. Callout colours are shared
   across all the tutorial sites: learning intentions amber, PRIMM green,
   note purple, tip light blue, warning pink. */
.md-typeset :is(.admonition, details) { --callout: #448aff; }
.md-typeset .admonition.learn, .md-typeset details.learn { --callout: #ffb300; }
.md-typeset .admonition.primm, .md-typeset details.primm { --callout: #4d8a00; }
.md-typeset .admonition.note,  .md-typeset details.note  { --callout: #8400ff; }
.md-typeset .admonition.tip,   .md-typeset details.tip   { --callout: #4fc3f7; }
.md-typeset .admonition.warning, .md-typeset details.warning { --callout: #ff00a1; }

/* Lighter PRIMM and note colours in dark mode */
[data-md-color-scheme="slate"] .md-typeset .admonition.primm,
[data-md-color-scheme="slate"] .md-typeset details.primm { --callout: #7bc41a; }
[data-md-color-scheme="slate"] .md-typeset .admonition.note,
[data-md-color-scheme="slate"] .md-typeset details.note { --callout: #b77bff; }

.md-typeset :is(.admonition, details),
.md-typeset :is(.admonition, details):is(.primm, .note, .tip, .warning, .learn) {
  --callout-border: color-mix(in srgb, var(--callout) 70%, black);
  border: 0.075rem solid var(--callout-border);
  background-color: color-mix(in srgb, var(--callout) 12%, transparent);
}

.md-typeset :is(.admonition, details):is(.primm, .note, .tip, .warning, .learn):focus-within {
  box-shadow: 0 0 0 .2rem color-mix(in srgb, var(--callout) 12%, transparent);
}

.md-typeset :is(.admonition, details) > :is(.admonition-title, summary),
.md-typeset :is(.primm, .note, .tip, .warning, .learn) > :is(.admonition-title, summary) {
  background-color: transparent;
}

.md-typeset :is(.admonition, details) > :is(.admonition-title, summary)::before,
.md-typeset :is(.primm, .note, .tip, .warning, .learn) > :is(.admonition-title, summary)::before {
  background-color: var(--callout-border);
}

.md-typeset :is(.admonition, details) > :is(.admonition-title, summary)::after,
.md-typeset :is(.primm, .note, .tip, .warning, .learn) > :is(.admonition-title, summary)::after {
  color: var(--callout-border);
}

/* Callout icons (Lucide, drawn as masks in the callout's darker shade):
   learning intentions target, PRIMM flask, code explanation </>,
   tip light bulb. Warning keeps the theme's triangle alert. */
:root {
  --md-admonition-icon--learn: url('data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>');
  --md-admonition-icon--primm: url('data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2"/><path d="M6.453 15h11.094"/><path d="M8.5 2h7"/></svg>');
  --md-admonition-icon--code: url('data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 16 4-4-4-4"/><path d="m6 8-4 4 4 4"/><path d="m14.5 4-5 16"/></svg>');
  --md-admonition-icon--bulb: url('data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg>');
}

.md-typeset .learn > :is(.admonition-title, summary)::before {
  -webkit-mask-image: var(--md-admonition-icon--learn);
  mask-image: var(--md-admonition-icon--learn);
}

.md-typeset .primm > :is(.admonition-title, summary)::before {
  -webkit-mask-image: var(--md-admonition-icon--primm);
  mask-image: var(--md-admonition-icon--primm);
}

.md-typeset .note > :is(.admonition-title, summary)::before {
  -webkit-mask-image: var(--md-admonition-icon--code);
  mask-image: var(--md-admonition-icon--code);
}

.md-typeset .tip > :is(.admonition-title, summary)::before {
  -webkit-mask-image: var(--md-admonition-icon--bulb);
  mask-image: var(--md-admonition-icon--bulb);
}

/* Code blocks: a thin border around every code block */
.md-typeset div.highlight {
  margin: 1em 0;
  border: 0.075rem solid var(--md-default-fg-color--lighter);
  border-radius: 0.4rem;
}

.md-typeset div.highlight .highlighttable,
.md-typeset div.highlight pre {
  margin: 0;
}

/* Error messages: red border and text */
.md-typeset div.error {
  border: 0.075rem solid #d00000;
  border-radius: 0.2rem;
}

.md-typeset div.error pre code {
  color: #d00000;
}

[data-md-color-scheme="slate"] .md-typeset div.error {
  border-color: #ff6b6b;
}

[data-md-color-scheme="slate"] .md-typeset div.error pre code {
  color: #ff6b6b;
}

.md-typeset div.error .md-code__nav,
.md-typeset div.error button {
  display: none;
}
```

Before handing over, screenshot every callout type, a code block and an error block in light and dark mode.

Every content page starts with a `learn` callout directly under the `# Title`, above the video if there is one (see `tutorial-page-style`). When migrating, turn each old "In this lesson you will learn" box into one, and write one for pages that didn't have it. Never drop the old learning intentions silently.

The home page explains the site's callouts, code blocks and (only if the site uses them) error messages, with a live example of each. Follow the Home page section of `tutorial-page-style`, and search the pages first so only features the site actually uses are explained.

## Phase 4: Build the content

Follow `tutorial-page-style` for pages and `tutorial-code-files` for code. Build section by section, and have the user preview each section before moving on:

1. `pip install -r requirements.txt`, then `zensical serve` (preview at http://localhost:8000).
2. Before handing over a batch, run `python scripts/make_zip.py`, `python scripts/check_explanations.py` (expect `0 issue(s) found`) and `zensical build --clean` (expect `No issues found`).

Fix real bugs found in the old site (wrong examples, swapped methods, outdated hardware specs, broken links) and list them for the user.

- Zensical's build checks internal links **and anchors** (`anchor does not exist`), so a clean build also proves every `page.md#heading` link works. Write the reference pages (for example an API page) early, because many lessons link to their headings.
- Run the build with `NO_COLOR=1` and filter the output to the `╭─[ file:line ]` lines, or the coloured report is unreadable in a log.
- Screenshot pages in light and dark mode with Playwright (open all `details` first so Code explanation boxes show).
- Mermaid diagrams need `pymdownx.superfences.custom_fences = [{ name = "mermaid", class = "mermaid", format = "pymdownx.superfences.fence_code_format" }]` in `zensical.toml`. The theme loads Mermaid from unpkg, which the cloud workspace blocks, so test the render by routing the script request to a local copy (`npm pack mermaid@11`).

## Working from Cowork: file transfer rules

These come from problems hit during the micro:bit migration:

- Mirror the repo in the cloud workspace, build and check there, then commit to the user's folder.
- Before changing a file, stage the device copy and compare it with the last committed copy (ignoring `\r`) to catch the user's own edits. Pass `expectedMtimeMs` when committing.
- Use a **new** staging folder for each commit (`/mnt/user-data/outputs/batch_<name>/`). Reusing a path can deliver stale content.
- Commit code and snippet files **before** the `.md`/`.toml` files that include them. Otherwise a running `zensical serve` rebuilds mid-copy and crashes with `SnippetMissingError`.
- After committing, re-stage a sample of the files and `cmp` them to verify. PNGs can be re-encoded in transit, so a PNG that fails `cmp` should be compared pixel by pixel (PIL `ImageChops.difference(...).getbbox()` is `None` when they match) before treating it as a problem.
- `device_commit_files` takes at most 50 files per call. Split large builds into batches (code and assets first, then pages, then `zensical.toml` last), and pass `expectedMtimeMs` for any file that already exists on the device.
- Before handing over, run every checkpoint or example that can run headless with scripted input (pipe commands to stdin, with stub modules for libraries like `ollama`), so broken code is found before the user tests it.
- Cowork can't delete files, run git, access GitHub or write inside `.github/`. Put those jobs in the handoff file.
- Tell the user when to commit and push in GitHub Desktop, and what commit message to use.
- For a big build, write a first batch (config, theme, home, the first section, placeholder pages for the rest of the nav) so the user can preview early, then keep building.
- The computer can drop offline mid-session. Keep each batch staged in its own outputs folder, save the progress note, attach a zip of the build, and tell the user what's still to be written. When they're back, list the device folder recursively and compare `mtimeMs` with the earlier commit times to catch their edits before writing the rest.
- To find what changed since the last batch, `filecmp` the repo mirror against the previous batch folder and stage only the differences.

### Check the branch before every write

The user's folder shows whichever branch is checked out in GitHub Desktop, and switching branches rewrites the files underneath you.

- Before each batch of writes, stage `.git/HEAD` and confirm it names the right branch: `zensical` before go-live, `main` after. If it's wrong, don't write; tell the user which branch the folder is on and which one it should be.
- If a commit is rejected because the device file changed since staging, re-stage and check `.git/HEAD` again before retrying. It's often a branch switch, not an edit.
- A checkout can change line endings to CRLF (the laptop's checkouts are CRLF). Compare files ignoring `\r`, and write back with the line endings the device file already has. Write new files with the same line endings as the repo's existing files.
- To work out what a branch contains, stage `.git/refs/heads/<branch>` and `.git/logs/HEAD` (the reflog), and decompress a loose commit object in `.git/objects/xx/…` with `zlib` to read its parents and message. This shows whether a merge included a given commit.

## Handing off to another computer

The user sometimes moves the work from the desktop to the laptop (or back). The cloud workspace doesn't follow them, so get the work into Git:

1. Save a progress note to the Claude project as `claude/<repo>_progress.md`: what's done, fixes made beyond the plan, and next steps. Attach a zip of the build to the chat as a backup.
2. Write the build into the repo on the linked computer, on the `zensical` branch (checking the branch first).
3. Guide the user one step at a time: commit in GitHub Desktop (give the commit message), then **Push origin**.
4. On the other computer: **Current repository** → select the repo and **Fetch origin**, or **File** → **Clone repository** if it isn't there yet. Then **Current branch** → `zensical`.
5. **Repository** → **Open in Visual Studio Code**, then paste the handoff prompt below into Claude in VS Code.

A Cowork session is linked to one computer. To keep working in Cowork on the other computer, the user opens the task there and chooses "Link to this computer", or starts a new task from that computer. A new task starts from the project's rework plan and progress note.

Claude in VS Code can't read the Claude project or the account skills:

- The user keeps copies of these skills in `%USERPROFILE%\.claude\skills\<skill-name>\SKILL.md` on the laptop. Whenever a skill changes, send a fresh zip of the updated `skills/` folders, and walk the user through copying it over the old folders and starting a new VS Code conversation.
- For a new migration started in VS Code, the prompt tells Claude to use these skills, to keep `REWORK_PLAN.md` and `PROGRESS.md` in the repo root (since it can't reach the project), to work on the `zensical` branch, and to ask before deleting, pushing, merging or changing GitHub settings.
- When handing a nearly finished site to VS Code, have the prompt first commit any pending work, run the three checks, and report any commits on `main` that `zensical` doesn't have.

## Adding content after the build

When the user asks for a new page or a change after the build has been pushed:

- Ask what the page is for, what it covers, whether it needs a worked example, and where it sits in the nav (multi-select options).
- Build it in the cloud workspace with the same snippet, check and screenshot routine. Show the user a preview and the source, and ask whether the voice is right before writing to the repo.
- Update everything that refers to it: the `nav` in `zensical.toml`, links from related pages, `make_zip.py` (if it adds examples), the zip, and the file counts and structure in `VSCODE_CLAUDE_TASKS.md`.
- Update the project progress note, then write to the repo on the linked computer (checking the branch and line endings first) and give the commit step.

## Phase 5: VS Code handoff file

Write `VSCODE_CLAUDE_TASKS.md` in the repo root for Claude in VS Code, and keep it current as conventions change. Structure:

1. Intro: why these tasks couldn't be done from Cowork; work on the `zensical` branch, in order; ask before any task marked **Confirm first**.
2. **Context:** generator and pinned version, preview and build commands, folder layout, colour scheme with roles, the standard callout and code block style, the check scripts, the page template, the example rules, the writing style (from `tutorial-page-style`), exercise-starter comment rules, and the location of the rework plan.
3. Numbered tasks, each with the exact files, commands and expected output. Typical tasks:
    - download missing third-party files such as drivers
    - verify API assumptions against source, and list each assumption (for example a third-party library such as `ollama`: record the version checked, and list the app and UI steps that couldn't be tested from Cowork)
    - delete leftover unused files (**Confirm first**; grep for references before deleting)
    - remove the old Sphinx files (**Confirm first**): numbered root pages, root `index.md`, `conf.py`, `Makefile`, `make.bat`, `_static/`, `_build/`, `_ext/`, old code and asset folders, duplicate licence and logo files, stray notes. Keep `LICENSE`, `README.md`, `todo.md`, `.gitignore`, `.gitattributes`, `requirements.txt`, `zensical.toml`, `docs/`, `scripts/` and `.github/`.
    - replace an MIT `LICENSE` with GPLv3 if the site's licence changed (**Confirm first**)
    - replace `.github/workflows/*.yml` with the Zensical Pages workflow below
    - rewrite the README (purpose, audience, preview, zip, checks, layout, licences)
    - final checks: zip, explanations, build, external link check (report broken links, don't guess replacements), Australian English spell-check, then commit and push
    - go live (**Confirm first**)
4. **Tasks for the user (not for Claude):** hardware testing, fixing diagrams or images (for example a class diagram whose labels don't match the code), playing through checkpoints, and decisions only the user can make.

Also write the user's tasks to `todo.md` in the repo root (replacing an old `todo.md` whose items have all become pages), grouped as play-testing, decisions, diagrams and anything in other repos. The user keeps this file as their own list, so the handoff file must say to keep it and not edit it, and it must not be in the cleanup list.

List every leftover file or folder found in the audit under the cleanup task, including stray folders the user adds during the migration (such as `Claude outputs/`), and ask about large source files (`.psd`) rather than deleting them.

Deploy workflow (runs only on `main`, so pushing `zensical` doesn't change the live site). Tell VS Code Claude to confirm each action version exists before committing:

```yaml
name: Deploy site
on:
  push:
    branches: [ main ]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - uses: actions/configure-pages@v6
      - uses: actions/checkout@v7
      - uses: actions/setup-python@v6
        with:
          python-version: 3.x
      - run: pip install -r requirements.txt
      - run: zensical build --clean
      - uses: actions/upload-pages-artifact@v5
        with:
          path: site
      - uses: actions/deploy-pages@v5
        id: deployment
```

The prompt for the user to paste into VS Code:

```
Read VSCODE_CLAUDE_TASKS.md in the repo root and work through the tasks in order on the zensical branch. Follow the Context section for style and structure. Stop and check with me before any task marked "Confirm first", and report the output of the checks after each task.
```

## Phase 6: Go live (in VS Code, Confirm first)

1. Tag `main` as `v1-sphinx` and push the tag, so the old site can be restored.
2. Merge `zensical` into `main` and push. The user may do this as a pull request on GitHub instead. A pull request only includes commits pushed before it was merged.
3. Set Pages to deploy from GitHub Actions: **Settings** → **Pages** → **Source**, or `gh api -X PUT repos/<owner>/<repo>/pages -f build_type=workflow`.
4. Watch the **Deploy site** run, then check the live URL.
5. Delete the old `gh-pages` branch only after the user confirms the new site works.
6. From now on, all work happens on `main`. Tell the user to switch GitHub Desktop to `main` and stay there. Any commit made on `zensical` after the merge doesn't reach the live site until `zensical` is merged into `main` again, so check with `.git/refs/heads/*` and the reflog, and walk the user through **Branch** → **Merge into current branch** if something was left behind. Update the handoff file's intro so it says to work on `main`.